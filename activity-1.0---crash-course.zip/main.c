#include<stdio.h>

int main()
{
    int grade;
    printf("Enter Grade: ");
    scanf("%d",&grade);
    if(grade >= 92 && grade <= 100)
    {
    printf("Your grade is A");
    }
    else if(grade >= 84 && grade <= 91)
    {
    printf("Your grade is A-");
    }
    else if(grade >= 76 && grade <= 83)
    {
    printf("Your grade is B");
    }
    else if(grade >= 68 && grade <= 75)
    {
    printf("Your grade is B-");
    }
    else if(grade >= 60 && grade <= 67)
    {
    printf("Your grade is C");
    }
    else if(grade >= 50 && grade <= 59)
    {
    printf("Your grade is D");
    }
    else if(grade >= 1 && grade <= 49)
    {
    printf("Your grade is F");
    }
    else if(grade > 100 || grade <= 0 )
    {
    printf("Invalid input");
    }
    return 0;
}