#include<stdio.h>

int main()
{
    int arrays[10], i, n, sum = 0, addition;
    printf("\nEnter Number of Elements:");
    scanf("%d", &n);

    if(n<=10){
    for(i=0; i < n; ++i){
    printf("Enter Number %d:", i+1);
    scanf("%d", &arrays[i]);

    sum=sum+arrays [i];
    }

    sum=sum+arrays[i];
    printf("Sum of all the Elements = %d", sum);
    return 0;
    }
    else{
    printf("\nlimit to 10 only arrays");
    }
}