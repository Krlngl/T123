#include <stdio.h>
#include <string.h>
 
int main() {
    
  	char arr[500];
  	
  	int a, b, len, str, fin;
    
  	printf("Enter any String: ");
  	
  	scanf("%[^\n]s", arr); 
  	
  	len = strlen(arr);
  	
  	fin = len - 1; 
 
  	
  	printf("Reverse ordered words: \n");
  	
  	for(a = len - 1; a >= 0; a--) { 
  	    
	    if(arr[a] == ' ' || a == 0) { 
	        
			if(a == 0) { 
				str = 0;  
			}
		    else { 
				str = a + 1; 
			}
			
		    for(b = str; b <= fin; b++) { 
		    
			printf("%c", arr[b]);
		    }
		    
			fin = a - 1; 
			printf(" ");		
		} 
	}
	
  	return 0;
}